#include <RcppArmadillo.h>
#include <RcppEigen.h>
#define NDEBUG
#include <assert.h>


using namespace arma;
using namespace Eigen;
