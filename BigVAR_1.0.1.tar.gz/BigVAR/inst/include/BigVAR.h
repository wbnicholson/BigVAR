#include <RcppArmadillo.h>
#include <RcppEigen.h>

using namespace arma;
using namespace Eigen;
