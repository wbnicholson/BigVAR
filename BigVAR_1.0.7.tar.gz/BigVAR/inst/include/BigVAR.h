#include <RcppArmadillo.h>
#include <RcppEigen.h>

using Eigen::MatrixXd;
using arma::mat;
using arma::cube;
using arma::colvec;
using arma::rowvec;
using arma::vec;
#define NDEBUG 1
