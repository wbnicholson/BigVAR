#include <RcppArmadillo.h>
#include <RcppEigen.h>

using Eigen::MatrixXd;
using arma::mat;
using arma::cube;
using arma::colvec;
#define NDEBUG 1
